public class Ornek16 {
    public static void main(String[] args) {

        String metin = "JAVA Dersi ve Android Dersi";

        // STRİNGİN TÜM KARAKTERLERİNİ BÜYÜK HARFE DÖNÜŞTÜRMEK
        System.out.println(metin.toUpperCase());
        // STRİNGİN TÜM KARAKTERLERİNİ KÜÇÜK HARFE DÖNÜŞTÜRMEK
        System.out.println(metin.toLowerCase());
        // STRİNGİN İLGİLİ İNDİSTE BULUNAN KARAKTERİNİ OKUMAK
        System.out.println(metin.charAt(1));

        // STRİNG DEĞERİN EŞİTLİĞİNİ KONTROL EDER
        boolean degerSerifMi = "şerif".equals(metin);
        // STRİNG DEĞERİN EŞİTLİĞİNİ KONTROL EDER (BÜYÜK HARF GÖZETMEKSİZİN)
        boolean degerSerifMi2 = "şerif".equalsIgnoreCase(metin);

        if(metin.contains("Ders")){
            System.out.println("içerisinde Ders kelimesi geçiyor");
        }else{
            System.out.println("içerisinde Ders kelimesi geçmiyor");
        }

        String website = "www.serifgungor.com";

        // METİNİN EN BAŞINDA ARAMA YAPAR
        if(website.startsWith("www")){
            System.out.println("site adresi www ile başlıyor");
        }else{
            System.out.println("site adresi www ile başlamıyor");
        }

        // METİNİN EN SONUNDA ARAMA YAPAR
        if(website.endsWith("www")){
            System.out.println("site adresi www ile bitiyor");
        }else{
            System.out.println("site adresi www ile bitmiyor");
        }

        // METİN İÇERİSİNDE ARANANIN İLK BULUNDUĞU İNDEXİ DÖNER
        // BULAMAZSA -1 DÖNER
        System.out.println(metin.indexOf("Ders"));

        // METİN İÇERİSİNDE ARANANIN SON BULUNDUĞU İNDEXİ DÖNER
        // BULAMAZSA -1 DÖNER

        int index = metin.lastIndexOf("Ders");

        System.out.println(index);

        // METİNDE KAÇ KARAKTER OLDUĞUNU DÖNER
        int karakterUzunlugu = metin.length();

        String test = "elma armut nar";

        String[] meyveler = test.split(" ");

        metin = metin.replace("JAVA","KOTLİN");








        if(degerSerifMi){
            System.out.println("Değer şerif");
        }else{
            System.out.println("Değer şerif değil");
        }

        String deneme = " test  ";
        deneme = deneme.trim();
        System.out.println(deneme);


    }
}
