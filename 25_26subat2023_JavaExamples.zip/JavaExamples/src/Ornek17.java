import java.util.Scanner;

public class Ornek17 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ad ve Soyadınızı giriniz");
        String adSoyad = sc.nextLine();
        System.out.println(adSoyad);

        adSoyad = adSoyad.toUpperCase();
        System.out.println(adSoyad);

        adSoyad = adSoyad.toLowerCase();
        System.out.println(adSoyad);





    }
}
