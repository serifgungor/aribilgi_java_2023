import java.util.Scanner;

public class Ornek18 {
    public static void main(String[] args) {

        String defaultUsername = "ArıBilgi123";
        String defaultPassword = "123456";

        Scanner sc = new Scanner(System.in);
        System.out.println("Kullanıcı adı giriniz");
        String username = sc.next();
        System.out.println("Şifre giriniz");
        String password = sc.next();

        if(
                username.equals(defaultUsername)
                &&
                password.equals(defaultPassword)
        ){
            System.out.println("Hoşgeldin");
        }else{
            System.out.println("Sizi tanımıyorum.");
        }



    }
}
