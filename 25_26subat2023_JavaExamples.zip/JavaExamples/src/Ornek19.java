public class Ornek19 {
    public static void main(String[] args) {

        String tbmm = "TÜRKİYE,BÜYÜK,MİLLET,MECLİSİ";
        String[] dizi = tbmm.split(",");


        for (int i = 0; i < dizi.length; i++) {
            System.out.println(dizi[i]);
        }


    }
}
