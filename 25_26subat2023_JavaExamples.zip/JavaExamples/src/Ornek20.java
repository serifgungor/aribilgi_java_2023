import java.util.Random;
import java.util.Scanner;

public class Ornek20 {
    static Random rnd;
    public static void main(String[] args) {

        /*
        Bir yerde new anahtar kelimesi kullanılarak, işlem yapılıyorsa
        orada nesne oluşturuluyordur.
         */
        rnd=new Random();

        int sayi1 = rnd.nextInt(5);
        int sayi2 = rnd.nextInt(5);

        if(sayi1>sayi2){
            System.out.println(sayi1+" sayısı "+sayi2+" sayısından büyüktür");
        }else if(sayi2>sayi1){
            System.out.println(sayi2+" sayısı "+sayi1+" sayısından büyüktür");
        }else{
            System.out.println("Sayılar eşittir. "+sayi1);
        }

    }

}