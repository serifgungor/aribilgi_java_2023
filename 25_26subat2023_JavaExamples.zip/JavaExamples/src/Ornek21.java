import java.util.Random;
import java.util.Scanner;

public class Ornek21 {
    static Scanner sc;
    static Random rnd;
    public static void main(String[] args) {

        sc = new Scanner(System.in);
        rnd = new Random();

        int sayi1 = sc.nextInt();
        int sayi2= rnd.nextInt(3);

        if(sayi1>sayi2){
            System.out.println("Büyük sayı girdiniz");
        }else if(sayi1<sayi2){
            System.out.println("Küçük sayı girdiniz");
        }else{
            System.out.println("Sayıyı buldunuz");
        }

    }
}
