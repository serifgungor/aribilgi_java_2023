import java.util.Scanner;

public class Ornek22 {
    static Scanner sc;
    public static void main(String[] args) {
        sc = new Scanner(System.in);

        System.out.println("1. sayıyı giriniz");
        int sayi1 = sc.nextInt();
        System.out.println("2. sayıyı giriniz");
        int sayi2 = sc.nextInt();

        System.out.println("1. sayınız: "+sayi1);
        System.out.println("2. sayınız: "+sayi2);
        int buyukSayi = Math.max(sayi1,sayi2);
        int kucukSayi = Math.min(sayi1,sayi2);
        System.out.println("Büyük sayı: "+buyukSayi);
        System.out.println("Küçük sayı: "+kucukSayi);





    }


}
