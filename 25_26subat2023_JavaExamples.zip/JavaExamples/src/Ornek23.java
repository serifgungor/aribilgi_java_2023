public class Ornek23 {
    public static void main(String[] args) {
        double s1 = 127.6;
        System.out.println(Math.ceil(s1)); // Bir üst sayıya yuvarlar

        System.out.println(Math.floor(s1)); // Küsüratı olmadan sayıyı döner

        System.out.println(Math.round(s1));// 0.5 sonrasını üst sayıya yuvarlar

        System.out.println(Math.random()); //0-1 arasında rastgele sayı üretir.

        System.out.println(Math.sqrt(4.2)); //Karekök alır



    }
}
