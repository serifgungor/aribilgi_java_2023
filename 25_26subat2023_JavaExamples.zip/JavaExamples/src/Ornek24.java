import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class Ornek24 {

    public static void main(String[] args) {

        Date tarih = new Date(); //Nesne ürettik
        //Tarihi ingilizce formatta döndürdü
        System.out.println(tarih.toString());
        //TimeStamp formatında zamanı getirir
        System.out.println(tarih.getTime());


        System.out.println("----");

        LocalDateTime dateTime = LocalDateTime.now();
        //Çıktı: 2023-02-26T16:46:30.390948900
        System.out.println(dateTime.toString());

        System.out.println("SAAT: "+dateTime.getHour());
        System.out.println("DAKİKA: "+dateTime.getMinute());
        System.out.println("SANİYE: "+dateTime.getSecond());
        System.out.println("MS: "+dateTime.getNano());
        System.out.println("AY: "+dateTime.getMonth().name());
        System.out.println("AY: "+dateTime.getMonthValue());
        System.out.println("YILIN GÜNÜ: "+dateTime.getDayOfYear());
        System.out.println("AYIN GÜNÜ: "+dateTime.getDayOfMonth());
        System.out.println("HAFTANIN GÜNÜ: "+dateTime.getDayOfWeek());


        //Zamanı istenilen formatta gösterebilmek için kullanılır
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String formattedDateTime = dateTime.format(dtf);
        System.out.println(formattedDateTime);

        Calendar takvim = Calendar.getInstance();




    }

}
