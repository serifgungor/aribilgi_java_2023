import java.util.Scanner;

public class Ornek25 {


    public static void main(String[] args) {

        // 5 elemanlı dizi oluşturduk
        int[] sayilar = new int[5];
        sayilar[0] = 5; //dizi elemanına değer atadık
        sayilar[1] = 7;
        sayilar[2] = 24;
        sayilar[3] = 42;
        sayilar[4] = 6;
        System.out.println(sayilar[0]); //elemanı çağırdık

        double[] sayiD = {12.4, 11.7, 5.01};


        String[] isimler = new String[5];
        isimler[0] = "ŞERİF";

        char[] karakterler = new char[5];
        karakterler[0]= 'Ş';
        karakterler[1]= 'E';
        karakterler[2]= 'R';
        karakterler[3]= 'İ';
        karakterler[4]= 'F';

        System.out.println(karakterler[0]);






    }
}
