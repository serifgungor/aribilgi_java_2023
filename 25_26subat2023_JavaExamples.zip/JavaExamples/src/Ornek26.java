import java.util.Scanner;

public class Ornek26 {
    static Scanner sc;
    public static void main(String[] args) {

        sc = new Scanner(System.in);

        int[] sayilar = new int[3];
        System.out.println("Sayı giriniz");
        sayilar[0] = sc.nextInt();
        System.out.println("Sayı giriniz");
        sayilar[1] = sc.nextInt();
        System.out.println("Sayı giriniz");
        sayilar[2] = sc.nextInt();

        System.out.println(sayilar[0]);
        System.out.println(sayilar[1]);
        System.out.println(sayilar[2]);

        /*
        sc = new Scanner(System.in);

        int[] sayilar = new int[3];
        System.out.println("Sayı giriniz");
        int sayi1 = sc.nextInt();
        System.out.println("Sayı giriniz");
        int sayi2 = sc.nextInt();
        System.out.println("Sayı giriniz");
        int sayi3 = sc.nextInt();

        sayilar[0] = sayi1;
        sayilar[1] = sayi2;
        sayilar[2] = sayi3;

        System.out.println(sayilar[0]);
        System.out.println(sayilar[1]);
        System.out.println(sayilar[2]);
        */




    }
}
