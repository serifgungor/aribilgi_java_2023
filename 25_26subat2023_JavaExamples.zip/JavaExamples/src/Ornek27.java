public class Ornek27 {
    public static void main(String[] args) {

        int A = 14;
        int B = 7;
        int G = 0;
        G = A;
        A = B;
        B = G;
        System.out.println("A: "+A);
        System.out.println("B: "+B);




    }
}
