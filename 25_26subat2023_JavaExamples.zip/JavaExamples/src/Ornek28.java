public class Ornek28 {

    public static void main(String[] args) {

        /*
        FOR - Başlangıç ve bitiş satıları aralığında dönmek için
        FOREACH - Dizi elemanlarını iterate etmek için kullanılır.
        WHİLE - Dosya işlemleri ve Veritabanı işlemlerinde tercih edilir.
                for döngüsü gibi de çalışır.
        DO-WHİLE - While şartı sağlanmasa bile en az 1 defa do bloğu çalışır.
         */

        for (int i = 1; i <= 5; i++) {
            System.out.print(i+" ");
        }


        int[] sayilar = {1,2,3,4,5};
        for (int sayi:sayilar) {
            System.out.println(sayi);
        }

        System.out.println("");
        int sayi = 0;
        while (sayi<5){
            System.out.println(sayi);
            sayi = sayi+1;
        }

        do{

        }while (sayi<5);



    }


}
