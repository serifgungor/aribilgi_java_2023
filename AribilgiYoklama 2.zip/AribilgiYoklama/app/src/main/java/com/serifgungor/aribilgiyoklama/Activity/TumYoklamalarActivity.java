package com.serifgungor.aribilgiyoklama.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.serifgungor.aribilgiyoklama.R;

public class TumYoklamalarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tum_yoklamalar);
        setTitle("Grubun Tüm Yoklamaları");
    }
}