package com.serifgungor.aribilgiyoklama.Model;

public class Ogrenci {
    private int ogrenciGrupId;
    private String ogrenciTcNo;
    private String ogrenciAdSoyad;

    public Ogrenci() {
    }

    public Ogrenci(int ogrenciGrupId, String ogrenciTcNo, String ogrenciAdSoyad) {
        this.ogrenciGrupId = ogrenciGrupId;
        this.ogrenciTcNo = ogrenciTcNo;
        this.ogrenciAdSoyad = ogrenciAdSoyad;
    }

    public int getOgrenciGrupId() {
        return ogrenciGrupId;
    }

    public String getOgrenciTcNo() {
        return ogrenciTcNo;
    }

    public void setOgrenciTcNo(String ogrenciTcNo) {
        this.ogrenciTcNo = ogrenciTcNo;
    }

    public void setOgrenciGrupId(int ogrenciGrupId) {
        this.ogrenciGrupId = ogrenciGrupId;
    }
    public String getOgrenciAdSoyad() {
        return ogrenciAdSoyad;
    }

    public void setOgrenciAdSoyad(String ogrenciAdSoyad) {
        this.ogrenciAdSoyad = ogrenciAdSoyad;
    }

    @Override
    public String toString() {
        return getOgrenciAdSoyad();
    }
}
