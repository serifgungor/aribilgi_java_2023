package com.serifgungor.aribilgiyoklama.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.serifgungor.aribilgiyoklama.R;

public class GrupOlusturActivity extends AppCompatActivity {
    EditText etGrupAdi,etGrupId,etGrupSaati;
    Button grupOlustur;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    public void init(){
        etGrupAdi = findViewById(R.id.etGrupAdi);
        etGrupId = findViewById(R.id.etGrupId);
        etGrupSaati = findViewById(R.id.etGrupSaati);
        grupOlustur = findViewById(R.id.btnGrupOlustur2);

        firebaseDatabase = FirebaseDatabase.getInstance();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grup_olustur);
        setTitle("Grup Oluştur");

        init();

        grupOlustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseReference = firebaseDatabase.getReference("Gruplar/"+etGrupId.getText().toString());
                databaseReference.child("grupAdi").setValue(etGrupAdi.getText().toString());
                databaseReference.child("grupSaati").setValue(etGrupSaati.getText().toString());
                finish();
            }
        });
    }
}