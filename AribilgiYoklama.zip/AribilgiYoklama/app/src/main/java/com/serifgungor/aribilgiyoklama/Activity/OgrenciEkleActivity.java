package com.serifgungor.aribilgiyoklama.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.serifgungor.aribilgiyoklama.Model.DersGrubu;
import com.serifgungor.aribilgiyoklama.R;

import java.util.ArrayList;

public class OgrenciEkleActivity extends AppCompatActivity {

    Spinner spGrup;
    EditText etOgrenciTc,etOgrenciAdSoyad;
    Button btnOgrenciyiKaydet;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    ArrayList<DersGrubu> dersGrubu;

    public void init(){
        spGrup = findViewById(R.id.spGrup);

        //Ders grupları firebase'den çekilecek
        dersGrubu = new ArrayList<>();
        dersGrubu.add(new DersGrubu(1,"Java Grubu",60));
        dersGrubu.add(new DersGrubu(2,"Java Android Grubu",110));


        ArrayAdapter<DersGrubu> arrayAdapter = new ArrayAdapter<DersGrubu>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                dersGrubu
        );
        spGrup.setAdapter(arrayAdapter);


        etOgrenciTc = findViewById(R.id.etOgrenciTcNo);
        etOgrenciAdSoyad = findViewById(R.id.etOgrenciAdSoyad);
        btnOgrenciyiKaydet = findViewById(R.id.btnOgrenciyiKaydet);

        firebaseDatabase = FirebaseDatabase.getInstance();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ogrenci_ekle);
        setTitle("Gruba Öğrenci Ekle");

        init();

        btnOgrenciyiKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                databaseReference = firebaseDatabase.getReference("OgrenciListesi/"+dersGrubu.get(spGrup.getSelectedItemPosition()).getGrupId());
                databaseReference.child(etOgrenciTc.getText().toString()).setValue(etOgrenciAdSoyad.getText().toString());
                finish();
            }
        });
    }
}