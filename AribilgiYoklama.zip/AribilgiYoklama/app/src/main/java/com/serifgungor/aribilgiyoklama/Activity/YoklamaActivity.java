package com.serifgungor.aribilgiyoklama.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.serifgungor.aribilgiyoklama.R;

public class YoklamaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoklama);
        setTitle("Yoklama Al");
    }
}