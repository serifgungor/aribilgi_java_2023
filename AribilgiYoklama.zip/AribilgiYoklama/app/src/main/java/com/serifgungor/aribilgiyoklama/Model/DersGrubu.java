package com.serifgungor.aribilgiyoklama.Model;

public class DersGrubu {
    private int grupId;
    private String grupAdi;
    private int grupSaati;

    public DersGrubu() {
    }

    public DersGrubu(int grupId, String grupAdi, int grupSaati) {
        this.grupId = grupId;
        this.grupAdi = grupAdi;
        this.grupSaati = grupSaati;
    }

    public int getGrupId() {
        return grupId;
    }

    public void setGrupId(int grupId) {
        this.grupId = grupId;
    }

    public String getGrupAdi() {
        return grupAdi;
    }

    public void setGrupAdi(String grupAdi) {
        this.grupAdi = grupAdi;
    }

    public int getGrupSaati() {
        return grupSaati;
    }

    public void setGrupSaati(int grupSaati) {
        this.grupSaati = grupSaati;
    }

    @Override
    public String toString() {
        return grupAdi;
    }
}
