package com.serifgungor.aribilgiyoklama.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.serifgungor.aribilgiyoklama.R;

public class MainActivity extends AppCompatActivity {

    Button btnGrupOlustur,btnGrubaOgrenciEkle,btnYoklamaAl,btnGrubunTumYoklamalari;


    public void init(){
        database = FirebaseDatabase.getInstance();
        btnGrubaOgrenciEkle = findViewById(R.id.btnGrubaOgrenciEkle);
        btnGrubunTumYoklamalari = findViewById(R.id.btnGrubunTumYoklamalari);
        btnYoklamaAl = findViewById(R.id.btnYoklamaAl);
        btnGrupOlustur = findViewById(R.id.btnGrupOlustur);
    }

    FirebaseDatabase database;
    DatabaseReference myRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.setTitle("Yoklama Sistemi");
        this.getSupportActionBar().setSubtitle("Arı Bilgi Yoklama Sistemi");
        init();

        myRef = database.getReference("OgrenciListesi/JavaAndroidGrubu");

        btnYoklamaAl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,YoklamaActivity.class));
            }
        });
        btnGrupOlustur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,GrupOlusturActivity.class));
            }
        });
        btnGrubaOgrenciEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,OgrenciEkleActivity.class));
            }
        });
        btnGrubunTumYoklamalari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,TumYoklamalarActivity.class));
            }
        });

/*
        myRef.child("1").setValue("YAKUP MERT");
        myRef.child("2").setValue("ŞERİF");
        myRef.child("3").setValue("FURKAN");
*/


    }
}