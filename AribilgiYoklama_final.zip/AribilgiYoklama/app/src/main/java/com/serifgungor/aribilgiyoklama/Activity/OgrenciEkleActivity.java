package com.serifgungor.aribilgiyoklama.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.serifgungor.aribilgiyoklama.Model.DersGrubu;
import com.serifgungor.aribilgiyoklama.Model.Ogrenci;
import com.serifgungor.aribilgiyoklama.R;

import java.util.ArrayList;

public class OgrenciEkleActivity extends AppCompatActivity {

    Spinner spGrup;
    EditText etOgrenciTc,etOgrenciAdSoyad;
    Button btnOgrenciyiKaydet;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    ArrayList<DersGrubu> dersGrubuArrayList = new ArrayList<>();
    ArrayAdapter<DersGrubu> arrayAdapter;


    public ArrayList<DersGrubu> gruplariGetir(){

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //.getKey() metodu bulunduğumuz Gruplar adlı referensı getirir.
                //Log.e("DENEME",snapshot.toString());

                //.toString() - Referans içerisindeki tüm verilerin JSON KARŞILIĞINI VERİR
                //{1={grupSaati=40, grupAdi=Android Online}, 500={grupSaati=60, grupAdi=Java Grubu}

                dersGrubuArrayList.clear();
                for (DataSnapshot snap: snapshot.getChildren()) {
                    DersGrubu dersGrubu = snap.getValue(DersGrubu.class);
                    Log.e("GRUP_BİLGİSİ",dersGrubu.getGrupAdi());

                    dersGrubuArrayList.add(new DersGrubu(Integer.parseInt(snap.getKey()),dersGrubu.getGrupAdi(),dersGrubu.getGrupSaati()));


                    //Log.e("GRUP_BİLGİSİ", String.valueOf(dersGrubu.getGrupId()));
                    //Log.e("GRUP_BİLGİSİ", String.valueOf(dersGrubu.getGrupSaati()));
                }
                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        //ArrayAdapter'ı gruplariGetir metoduna taşımamızın sebebi verilerin firebase'den geldikten sonra
        //arrayliste eklenip spinner'da gösterilmesi için arrayadapter'ın güncellenmesi gerekir.


        return dersGrubuArrayList;
    }


    public void init(){
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("Gruplar");

        spGrup = findViewById(R.id.spGrup);

        //Ders grupları firebase'den çekilecek
        dersGrubuArrayList = gruplariGetir();

        arrayAdapter = new ArrayAdapter<DersGrubu>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                dersGrubuArrayList
        );
        spGrup.setAdapter(arrayAdapter);

        etOgrenciTc = findViewById(R.id.etOgrenciTcNo);
        etOgrenciAdSoyad = findViewById(R.id.etOgrenciAdSoyad);
        btnOgrenciyiKaydet = findViewById(R.id.btnOgrenciyiKaydet);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ogrenci_ekle);
        setTitle("Gruba Öğrenci Ekle");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();

        btnOgrenciyiKaydet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Ogrenci ogrenci = new Ogrenci();
                ogrenci.setOgrenciTcNo(etOgrenciTc.getText().toString());
                ogrenci.setOgrenciAdSoyad(etOgrenciAdSoyad.getText().toString());
                ogrenci.setOgrenciGrupId(dersGrubuArrayList.get(spGrup.getSelectedItemPosition()).getGrupId());


                databaseReference = firebaseDatabase.getReference("OgrenciListesi/"+dersGrubuArrayList.get(spGrup.getSelectedItemPosition()).getGrupId());

                databaseReference.child(
                        etOgrenciTc.getText().toString()
                ).setValue(ogrenci);


                finish();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}