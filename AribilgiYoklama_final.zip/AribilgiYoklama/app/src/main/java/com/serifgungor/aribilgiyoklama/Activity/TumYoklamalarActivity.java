package com.serifgungor.aribilgiyoklama.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.serifgungor.aribilgiyoklama.Model.DersGrubu;
import com.serifgungor.aribilgiyoklama.Model.OgrenciYoklama;
import com.serifgungor.aribilgiyoklama.R;

import java.util.ArrayList;

public class TumYoklamalarActivity extends AppCompatActivity {

    Spinner spYoklamaTum,spYoklamaTarih;
    LinearLayout linearYoklamaTum;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ArrayList<DersGrubu> dersGrubuArrayList = new ArrayList<>();
    ArrayList<String> tarihArrayList = new ArrayList<>();
    ArrayAdapter<DersGrubu> arrayAdapter;
    ArrayAdapter<String> arrayAdapterTarihler;

    int sonSecilenGrupId = 0;


    public void init(){
        spYoklamaTarih = findViewById(R.id.spYoklamaTarih);
        spYoklamaTum = findViewById(R.id.spYoklamaTum);
        linearYoklamaTum = findViewById(R.id.linearYoklamaTum);

        firebaseDatabase = FirebaseDatabase.getInstance();

        gruplariGetir();

        arrayAdapter = new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item,dersGrubuArrayList);
        spYoklamaTum.setAdapter(arrayAdapter);


        arrayAdapterTarihler = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                tarihArrayList
        );
        spYoklamaTarih.setAdapter(arrayAdapterTarihler);

    }



    public ArrayList<String> tariheGoreYoklamayiGetir(int grupId,String tarih){
        ArrayList<String> ogrenciListesi = new ArrayList<>();

        databaseReference = firebaseDatabase.getReference("Yoklamalar/"+grupId+"/"+tarih);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                linearYoklamaTum.removeAllViews();
                for (DataSnapshot ds:snapshot.getChildren()) {

                    OgrenciYoklama ogrenci = ds.getValue(OgrenciYoklama.class);

                    if(ogrenci.isOgrenciKatilimDurumu()==true){
                        ogrenciListesi.add(ogrenci.getOgrenciAdSoyad());

                        TextView tvOgrenci = new TextView(getApplicationContext());
                        tvOgrenci.setText(ogrenci.getOgrenciAdSoyad());

                        linearYoklamaTum.addView(tvOgrenci);

                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        return ogrenciListesi;
    }


    public ArrayList<String> grubunYoklamaTarihleriniGetir(int grupId){


        databaseReference = firebaseDatabase.getReference("Yoklamalar/"+grupId);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                tarihArrayList.clear();
                for (DataSnapshot ds:snapshot.getChildren()) {
                    tarihArrayList.add(ds.getKey());
                }
                arrayAdapterTarihler.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        return tarihArrayList;
    }

    public ArrayList<DersGrubu> gruplariGetir(){
        databaseReference = firebaseDatabase.getReference("Gruplar");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //.getKey() metodu bulunduğumuz Gruplar adlı referensı getirir.
                //Log.e("DENEME",snapshot.toString());

                //.toString() - Referans içerisindeki tüm verilerin JSON KARŞILIĞINI VERİR
                //{1={grupSaati=40, grupAdi=Android Online}, 500={grupSaati=60, grupAdi=Java Grubu}

                dersGrubuArrayList.clear();
                for (DataSnapshot snap: snapshot.getChildren()) {
                    DersGrubu dersGrubu = snap.getValue(DersGrubu.class);
                    Log.e("GRUP_BİLGİSİ",dersGrubu.getGrupAdi());

                    dersGrubuArrayList.add(new DersGrubu(Integer.parseInt(snap.getKey()),dersGrubu.getGrupAdi(),dersGrubu.getGrupSaati()));

                    //Log.e("GRUP_BİLGİSİ", String.valueOf(dersGrubu.getGrupId()));
                    //Log.e("GRUP_BİLGİSİ", String.valueOf(dersGrubu.getGrupSaati()));
                }

                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        //ArrayAdapter'ı gruplariGetir metoduna taşımamızın sebebi verilerin firebase'den geldikten sonra
        //arrayliste eklenip spinner'da gösterilmesi için arrayadapter'ın güncellenmesi gerekir.


        return dersGrubuArrayList;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tum_yoklamalar);
        setTitle("Grubun Tüm Yoklamaları");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();

        spYoklamaTarih.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                tariheGoreYoklamayiGetir(sonSecilenGrupId,tarihArrayList.get(i));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spYoklamaTum.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                tarihArrayList = grubunYoklamaTarihleriniGetir(dersGrubuArrayList.get(i).getGrupId());
                sonSecilenGrupId = dersGrubuArrayList.get(i).getGrupId();



                //1 arrayadapter daha oluştur bu alttaki spinner'ı doldursun.


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}