package com.serifgungor.aribilgiyoklama.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.serifgungor.aribilgiyoklama.Model.DersGrubu;
import com.serifgungor.aribilgiyoklama.Model.Ogrenci;
import com.serifgungor.aribilgiyoklama.Model.OgrenciYoklama;
import com.serifgungor.aribilgiyoklama.R;

import java.util.ArrayList;
import java.util.Calendar;

public class YoklamaActivity extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    Spinner spYoklama;
    LinearLayout linearYoklama;

    ArrayList<DersGrubu> dersGrubuArrayList = new ArrayList<>();

    ArrayAdapter<DersGrubu> arrayAdapter;

    int sonSeciliGrupId = 0;

    public void init(){
        firebaseDatabase = FirebaseDatabase.getInstance();
        spYoklama = findViewById(R.id.spYoklama);
        linearYoklama = findViewById(R.id.linearYoklama);



        gruplariGetir();

        arrayAdapter = new ArrayAdapter<DersGrubu>(
                getApplicationContext(),
                android.R.layout.simple_spinner_dropdown_item,
                dersGrubuArrayList
        );
        spYoklama.setAdapter(arrayAdapter);
    }


    public ArrayList<Ogrenci> ogrencileriGetir(int grupId){
        ArrayList<Ogrenci> ogrenciler = new ArrayList<>();

        databaseReference = firebaseDatabase.getReference("OgrenciListesi/"+grupId);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                linearYoklama.removeAllViews();

                for (DataSnapshot snap:snapshot.getChildren()) {
                    Ogrenci ogrenci = snap.getValue(Ogrenci.class);

                    CheckBox chkOgrenci = new CheckBox(getApplicationContext());
                    chkOgrenci.setText( ogrenci.getOgrenciAdSoyad()+ ";" + ogrenci.getOgrenciTcNo());
                    chkOgrenci.setOnCheckedChangeListener(YoklamaActivity.this::onCheckedChanged);

                    linearYoklama.addView(chkOgrenci);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        return ogrenciler;
    }



    public ArrayList<DersGrubu> gruplariGetir(){
        databaseReference = firebaseDatabase.getReference("Gruplar");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //.getKey() metodu bulunduğumuz Gruplar adlı referensı getirir.
                //Log.e("DENEME",snapshot.toString());

                //.toString() - Referans içerisindeki tüm verilerin JSON KARŞILIĞINI VERİR
                //{1={grupSaati=40, grupAdi=Android Online}, 500={grupSaati=60, grupAdi=Java Grubu}

                dersGrubuArrayList.clear();
                for (DataSnapshot snap: snapshot.getChildren()) {
                    DersGrubu dersGrubu = snap.getValue(DersGrubu.class);
                    Log.e("GRUP_BİLGİSİ",dersGrubu.getGrupAdi());

                    dersGrubuArrayList.add(new DersGrubu(Integer.parseInt(snap.getKey()),dersGrubu.getGrupAdi(),dersGrubu.getGrupSaati()));

                    //Log.e("GRUP_BİLGİSİ", String.valueOf(dersGrubu.getGrupId()));
                    //Log.e("GRUP_BİLGİSİ", String.valueOf(dersGrubu.getGrupSaati()));
                }

                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        //ArrayAdapter'ı gruplariGetir metoduna taşımamızın sebebi verilerin firebase'den geldikten sonra
        //arrayliste eklenip spinner'da gösterilmesi için arrayadapter'ın güncellenmesi gerekir.


        return dersGrubuArrayList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yoklama);
        setTitle("Yoklama Al");
        this.getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        init();


        spYoklama.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Log.e("ÖGRENCİ_BİLGİSİ","metot çalıştı");
                ogrencileriGetir(gruplariGetir().get(i).getGrupId());
                sonSeciliGrupId = gruplariGetir().get(i).getGrupId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        String value = ((CheckBox)compoundButton).getText().toString();

        String ogrenciAdSoyad = value.split(";")[0];
        String ogrenciTc = value.split(";")[1];

        Log.e("CHECK_STATE",ogrenciAdSoyad);
        Log.e("CHECK_STATE",ogrenciTc);


        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1; // Ayın başlangıcı 0 olarak kabul edildiği için 1 ekliyoruz.
        int year = calendar.get(Calendar.YEAR);

        String tarih = day+"_"+month+"_"+year; //04.06.2023

        databaseReference = firebaseDatabase.getReference("Yoklamalar/"+sonSeciliGrupId+"/"+tarih);

        OgrenciYoklama yoklama = new OgrenciYoklama();
        yoklama.setOgrenciAdSoyad(ogrenciAdSoyad);
        yoklama.setOgrenciTcNo(ogrenciTc);
        yoklama.setOgrenciKatilimDurumu(b);

        databaseReference.child(ogrenciTc).setValue(yoklama);


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}