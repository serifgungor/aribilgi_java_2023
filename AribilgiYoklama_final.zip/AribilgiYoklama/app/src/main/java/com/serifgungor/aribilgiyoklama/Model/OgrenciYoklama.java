package com.serifgungor.aribilgiyoklama.Model;

public class OgrenciYoklama {
    private String ogrenciTcNo;
    private String ogrenciAdSoyad;
    private boolean ogrenciKatilimDurumu;

    public OgrenciYoklama() {
    }

    public OgrenciYoklama(String ogrenciTcNo, String ogrenciAdSoyad, boolean ogrenciKatilimDurumu) {
        this.ogrenciTcNo = ogrenciTcNo;
        this.ogrenciAdSoyad = ogrenciAdSoyad;
        this.ogrenciKatilimDurumu = ogrenciKatilimDurumu;
    }

    public String getOgrenciTcNo() {
        return ogrenciTcNo;
    }

    public void setOgrenciTcNo(String ogrenciTcNo) {
        this.ogrenciTcNo = ogrenciTcNo;
    }

    public String getOgrenciAdSoyad() {
        return ogrenciAdSoyad;
    }

    public void setOgrenciAdSoyad(String ogrenciAdSoyad) {
        this.ogrenciAdSoyad = ogrenciAdSoyad;
    }

    public boolean isOgrenciKatilimDurumu() {
        return ogrenciKatilimDurumu;
    }

    public void setOgrenciKatilimDurumu(boolean ogrenciKatilimDurumu) {
        this.ogrenciKatilimDurumu = ogrenciKatilimDurumu;
    }
}
