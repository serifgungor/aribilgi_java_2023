package com.serifgungor.arrayadapter;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GridViewActivity extends AppCompatActivity {

    GridView gridView;
    ArrayList<String> meyveler = new ArrayList<>();
    ArrayAdapter<String> adapterMeyveler;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_view);

        gridView = findViewById(R.id.gridView);

        meyveler.add("ELMA");
        meyveler.add("ERİK");
        meyveler.add("ŞEFTALİ");
        meyveler.add("KİRAZ");
        meyveler.add("KAYISI");
        meyveler.add("KARPUZ");
        meyveler.add("KİVİ");
        meyveler.add("NAR");
        meyveler.add("GREYFURT");

        adapterMeyveler = new ArrayAdapter<>(
                getApplication(),
                android.R.layout.simple_list_item_1,
                meyveler
        );

        gridView.setAdapter(adapterMeyveler);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(getApplicationContext(),meyveler.get(i),Toast.LENGTH_LONG).show();
            }
        });


    }
}
