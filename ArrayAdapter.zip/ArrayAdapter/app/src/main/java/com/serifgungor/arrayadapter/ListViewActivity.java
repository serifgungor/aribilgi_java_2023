package com.serifgungor.arrayadapter;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListViewActivity extends AppCompatActivity {

    ListView listView;

    ArrayList<String> ulkeler = new ArrayList<>();
    ArrayAdapter<String> ulkelerAdapter;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view);

        listView = findViewById(R.id.listele);

        ulkeler.add("TÜRKİYE");
        ulkeler.add("AZERBAYCAN");
        ulkeler.add("İRAN");
        ulkeler.add("IRAK");
        ulkeler.add("K.K.T.C.");
        ulkeler.add("BULGARİSTAN");
        ulkeler.add("YUNANİSTAN");

        ulkelerAdapter = new ArrayAdapter<>(
                getApplicationContext(),
                android.R.layout.simple_list_item_1,
                ulkeler
        );

        listView.setAdapter(ulkelerAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(
                        getApplicationContext(),
                        ulkeler.get(i),
                        Toast.LENGTH_LONG
                ).show();
            }
        });

    }
}