package com.serifgungor.messagingapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.serifgungor.messagingapp.Model.Kullanici;
import com.serifgungor.messagingapp.R;

import java.util.Date;

public class RegisterActivity extends AppCompatActivity {

    EditText etAdSoyad, etSifre, etMail, etTelefon;
    Button btnKayit;
    FirebaseDatabase database;
    DatabaseReference dbRef;

    public void init() {
        btnKayit = findViewById(R.id.btnRegisterNow);
        etAdSoyad = findViewById(R.id.etNameSurnameRegister);
        etSifre = findViewById(R.id.etPasswordRegister);
        etMail = findViewById(R.id.etEmailRegister);
        etTelefon = findViewById(R.id.etPhoneRegister);
        database = FirebaseDatabase.getInstance();
        dbRef = database.getReference();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        init();

        btnKayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!etAdSoyad.getText().toString().isEmpty()
                        &&
                        !etTelefon.getText().toString().isEmpty()
                        &&
                        !etMail.getText().toString().isEmpty()
                        &&
                        !etSifre.getText().toString().isEmpty()
                ){
                    String uniqueId = String.valueOf(new Date().getTime());
                    Kullanici kullanici = new Kullanici();
                    kullanici.setKullanici_unique_id(uniqueId);
                    kullanici.setKullanici_ad_soyad(etAdSoyad.getText().toString());
                    kullanici.setKullanici_mail(etMail.getText().toString());
                    kullanici.setKullanici_sifre(etSifre.getText().toString());
                    kullanici.setKullanici_phone_no(etTelefon.getText().toString());

                    dbRef.child("kullanicilar").child(uniqueId).setValue(kullanici);
                    finish();
                }else{
                    Toast.makeText(getApplicationContext(),"Boş alan bırakılamaz",Toast.LENGTH_LONG).show();
                }


            }
        });
    }
}