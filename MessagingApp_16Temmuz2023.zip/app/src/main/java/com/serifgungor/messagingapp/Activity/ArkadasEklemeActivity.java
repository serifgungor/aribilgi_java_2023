package com.serifgungor.messagingapp.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.serifgungor.messagingapp.Model.Arkadas;
import com.serifgungor.messagingapp.Model.Kullanici;
import com.serifgungor.messagingapp.R;

import java.util.Date;

public class ArkadasEklemeActivity extends AppCompatActivity {

    EditText etTelefonNo;
    Button btnArkadasEkle;

    FirebaseDatabase database;
    DatabaseReference dbRef;

    SharedPreferences sp;
    SharedPreferences.Editor spe;

    Kullanici kullanici;

    public void init(){
        etTelefonNo = findViewById(R.id.etTelefonNo);
        btnArkadasEkle = findViewById(R.id.btnArkadasEkle);
        database = FirebaseDatabase.getInstance();
        dbRef = database.getReference();

        sp = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        spe = sp.edit();
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arkadas_ekleme);

        init();

        btnArkadasEkle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //ÖNCE SORGULAMA SONRA EKLEME



                dbRef.child("kullanicilar").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for (DataSnapshot ds:snapshot.getChildren()) {
                            Kullanici k = ds.getValue(Kullanici.class);

                            if(etTelefonNo.getText().toString().equals(k.getKullanici_phone_no())){
                                kullanici = k;

                                String arkadas_unique_id = String.valueOf(new Date().getTime());
                                String arkadas_eklenen_id = k.getKullanici_unique_id();
                                String arkadas_ekleyen_id = sp.getString("userid","");
                                int durum_id = 1;

                                Arkadas arkadas = new Arkadas();
                                arkadas.setDurum_id(durum_id);
                                arkadas.setArkadas_unique_id(arkadas_unique_id);
                                arkadas.setArkadas_ekleyen_id(arkadas_ekleyen_id);
                                arkadas.setArkadas_eklenen_id(arkadas_eklenen_id);

                                dbRef.child("arkadaslar").child(arkadas_unique_id).setValue(arkadas);

                                break;
                            }


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });



            }
        });
    }
}