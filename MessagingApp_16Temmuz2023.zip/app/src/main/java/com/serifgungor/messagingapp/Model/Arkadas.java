package com.serifgungor.messagingapp.Model;

import java.io.Serializable;

public class Arkadas implements Serializable {
    private String arkadas_unique_id;
    private String arkadas_ekleyen_id;
    private String arkadas_eklenen_id;
    private int durum_id;

    public Arkadas() {
    }

    public Arkadas(String arkadas_unique_id, String arkadas_ekleyen_id, String arkadas_eklenen_id, int durum_id) {
        this.arkadas_unique_id = arkadas_unique_id;
        this.arkadas_ekleyen_id = arkadas_ekleyen_id;
        this.arkadas_eklenen_id = arkadas_eklenen_id;
        this.durum_id = durum_id;
    }

    public String getArkadas_unique_id() {
        return arkadas_unique_id;
    }

    public void setArkadas_unique_id(String arkadas_unique_id) {
        this.arkadas_unique_id = arkadas_unique_id;
    }

    public String getArkadas_ekleyen_id() {
        return arkadas_ekleyen_id;
    }

    public void setArkadas_ekleyen_id(String arkadas_ekleyen_id) {
        this.arkadas_ekleyen_id = arkadas_ekleyen_id;
    }

    public String getArkadas_eklenen_id() {
        return arkadas_eklenen_id;
    }

    public void setArkadas_eklenen_id(String arkadas_eklenen_id) {
        this.arkadas_eklenen_id = arkadas_eklenen_id;
    }

    public int getDurum_id() {
        return durum_id;
    }

    public void setDurum_id(int durum_id) {
        this.durum_id = durum_id;
    }
}
