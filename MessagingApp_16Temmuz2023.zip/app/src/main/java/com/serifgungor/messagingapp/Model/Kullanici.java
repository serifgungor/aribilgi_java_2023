package com.serifgungor.messagingapp.Model;

public class Kullanici {
    private String kullanici_unique_id;
    private String kullanici_ad_soyad;
    private String kullanici_sifre;
    private String kullanici_phone_no;
    private String kullanici_mail;
    private String kullanici_telefon_macid;
    private String kullanici_resim;
    private String kullanici_aciklama_yazisi;

    public Kullanici() {
    }

    public Kullanici(String kullanici_unique_id, String kullanici_ad_soyad, String kullanici_sifre, String kullanici_phone_no, String kullanici_mail, String kullanici_telefon_macid, String kullanici_resim, String kullanici_aciklama_yazisi) {
        this.kullanici_unique_id = kullanici_unique_id;
        this.kullanici_ad_soyad = kullanici_ad_soyad;
        this.kullanici_sifre = kullanici_sifre;
        this.kullanici_phone_no = kullanici_phone_no;
        this.kullanici_mail = kullanici_mail;
        this.kullanici_telefon_macid = kullanici_telefon_macid;
        this.kullanici_resim = kullanici_resim;
        this.kullanici_aciklama_yazisi = kullanici_aciklama_yazisi;
    }

    public String getKullanici_unique_id() {
        return kullanici_unique_id;
    }

    public void setKullanici_unique_id(String kullanici_unique_id) {
        this.kullanici_unique_id = kullanici_unique_id;
    }

    public String getKullanici_ad_soyad() {
        return kullanici_ad_soyad;
    }

    public void setKullanici_ad_soyad(String kullanici_ad_soyad) {
        this.kullanici_ad_soyad = kullanici_ad_soyad;
    }

    public String getKullanici_sifre() {
        return kullanici_sifre;
    }

    public void setKullanici_sifre(String kullanici_sifre) {
        this.kullanici_sifre = kullanici_sifre;
    }

    public String getKullanici_phone_no() {
        return kullanici_phone_no;
    }

    public void setKullanici_phone_no(String kullanici_phone_no) {
        this.kullanici_phone_no = kullanici_phone_no;
    }

    public String getKullanici_mail() {
        return kullanici_mail;
    }

    public void setKullanici_mail(String kullanici_mail) {
        this.kullanici_mail = kullanici_mail;
    }

    public String getKullanici_telefon_macid() {
        return kullanici_telefon_macid;
    }

    public void setKullanici_telefon_macid(String kullanici_telefon_macid) {
        this.kullanici_telefon_macid = kullanici_telefon_macid;
    }

    public String getKullanici_resim() {
        return kullanici_resim;
    }

    public void setKullanici_resim(String kullanici_resim) {
        this.kullanici_resim = kullanici_resim;
    }

    public String getKullanici_aciklama_yazisi() {
        return kullanici_aciklama_yazisi;
    }

    public void setKullanici_aciklama_yazisi(String kullanici_aciklama_yazisi) {
        this.kullanici_aciklama_yazisi = kullanici_aciklama_yazisi;
    }
}
